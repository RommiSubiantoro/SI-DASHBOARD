import React, { useState, useEffect, useRef } from 'react';
import { getAuth, onAuthStateChanged } from 'firebase/auth';
import { LogOut, User, ChevronDown } from 'lucide-react';
import '../css/Navbar.css';

const Navbar = ({ onLogout }) => {
  const [user, setUser] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [showDropdown, setShowDropdown] = useState(false);
  const [loading, setLoading] = useState(true);
  const dropdownRef = useRef(null);
  const auth = getAuth();

  // Listen to auth state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        
        try {
          setUserProfile({
            email: currentUser.email,
            displayName: currentUser.displayName || currentUser.email?.split('@')[0] || 'User',
            photoURL: currentUser.photoURL,
            uid: currentUser.uid
          });
        } catch (error) {
          console.error('Error fetching user profile:', error);
          setUserProfile({
            email: currentUser.email,
            displayName: currentUser.email?.split('@')[0] || 'User',
            photoURL: null,
            uid: currentUser.uid
          });
        }
      } else {
        setUser(null);
        setUserProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [auth]);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setShowDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Generate initials from email or display name
  const getInitials = (email, displayName) => {
    if (displayName) {
      return displayName.split(' ')
        .map(name => name[0])
        .join('')
        .toUpperCase()
        .substring(0, 2);
    }
    if (email) {
      return email.substring(0, 2).toUpperCase();
    }
    return 'U';
  };

  // Handle logout
  const handleLogout = async () => {
    try {
      setShowDropdown(false);
      if (onLogout) {
        onLogout();
      }
    } catch (error) {
      console.error('Error during logout:', error);
    }
  };

  if (loading) {
    return (
      <nav className="navbar">
        <div className="navbar-container">
          <div className="navbar-logo">
            <h2>Admin Panel</h2>
          </div>
          <div className="navbar-loading">
            <div className="loading-spinner"></div>
          </div>
        </div>
      </nav>
    );
  }

  return (
    <nav className="navbar">
      <div className="navbar-container">
        {/* Logo Section */}
        <div className="navbar-logo">
          
          <h2 className="logo-text">Samudera Indonesia</h2>
        </div>

        {/* User Profile Section */}
        {userProfile && (
          <div className="navbar-user" ref={dropdownRef}>
            <div 
              className="user-info"
              onClick={() => setShowDropdown(!showDropdown)}
            >
              <div className="user-details">
                <span className="user-name">{userProfile.displayName}</span>
                <span className="user-email">{userProfile.email}</span>
              </div>
              
              <div className="user-avatar">
                {userProfile.photoURL ? (
                  <img 
                    src={userProfile.photoURL} 
                    alt="User Avatar" 
                    className="avatar-image"
                  />
                ) : (
                  <div className="avatar-placeholder">
                    {getInitials(userProfile.email, userProfile.displayName)}
                  </div>
                )}
              </div>
              
              <ChevronDown 
                className={`dropdown-icon ${showDropdown ? 'rotated' : ''}`} 
                size={16} 
              />
            </div>

            {/* Dropdown Menu */}
            {showDropdown && (
              <div className="dropdown-menu">
                <div className="dropdown-header">
                  <div className="dropdown-avatar">
                    {userProfile.photoURL ? (
                      <img 
                        src={userProfile.photoURL} 
                        alt="User Avatar" 
                        className="dropdown-avatar-image"
                      />
                    ) : (
                      <div className="dropdown-avatar-placeholder">
                        {getInitials(userProfile.email, userProfile.displayName)}
                      </div>
                    )}
                  </div>
                  <div className="dropdown-user-info">
                    <div className="dropdown-name">{userProfile.displayName}</div>
                    <div className="dropdown-email">{userProfile.email}</div>
                  </div>
                </div>
                
                <div className="dropdown-divider"></div>
                
                <div className="dropdown-items">
                  <button 
                    className="dropdown-item profile-item"
                    onClick={() => setShowDropdown(false)}
                  >
                    <User size={16} />
                    <span>Profile Settings</span>
                  </button>
                  
                  <button 
                    className="dropdown-item logout-item"
                    onClick={handleLogout}
                  >
                    <LogOut size={16} />
                    <span>Logout</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* If no user is logged in */}
        {!userProfile && (
          <div className="navbar-auth">
            <div className="auth-placeholder">
              <User size={24} />
              <span>Not logged in</span>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;