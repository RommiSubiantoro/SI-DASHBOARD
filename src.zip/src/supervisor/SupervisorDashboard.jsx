import React from 'react'

function SupervisorDashboard() {
  return (
    <div className='container-spv'>
      <div>
        <p>Supervisor Dashboard</p>
        <div>
            
        </div>
      </div>
    </div>
  )
}

export default SupervisorDashboard